## -*- coding: utf-8 -*-


def imprimirNodo(nodo):
    print ((nodo))