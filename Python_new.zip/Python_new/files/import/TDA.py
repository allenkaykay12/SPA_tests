## -*- coding: utf-8 -*-

nodo = {
    "nombre": "juan",
    "edad": 15
    }