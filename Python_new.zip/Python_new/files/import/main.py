# -*- coding: utf-8 -*-

"""incluir un información de otro archivo"""
import TDA
import imprimirTDA

if __name__ == '__main__':
    imprimirTDA.imprimirNodo(TDA.nodo)
