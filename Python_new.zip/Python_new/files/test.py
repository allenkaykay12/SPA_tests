input("Dame tu nombre:\n")

Anaconda navigator
