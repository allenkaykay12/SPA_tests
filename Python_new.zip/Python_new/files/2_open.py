# -*- coding: utf-8 -*-

############## Manejo de archivos ##############

# Leer archivo completo
f = open("archivo.txt", "r")
print(f)
