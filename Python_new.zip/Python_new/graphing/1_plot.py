import matplotlib.pyplot as plt
# %matplotlib_inline #para jupyter notebook
#Grafica 2 vectores
plt.plot([1,2,3,4]) #Vector en Y
#Grafica por defecto el vecto X = 1, 2, 3, 4
plt.title('Title')
plt.ylabel('some Y numbers')
plt.xlabel('some X numbers')
plt.show()
