# -*- coding: utf-8 -*-

# --------------- Uso de expresiones matemáticas ---------------

# La funcion print sirve para imprimir valores en la pantalla
# NOTA: La funcion print en python 3 debe utilizar paréntesis,
# en python 2 se usa sin paréntesis.

print (1 + 5)
print (6 * 3)
print (10 - 4)
print (100 / 50)
print (10 % 2)
print (10 // 2)
print (10 / 2)
print(2**3)
print(2**3+5*3)
print (((20 * 3) + (10 + 1)) / 10)
