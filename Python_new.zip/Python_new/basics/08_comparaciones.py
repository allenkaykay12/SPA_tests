# -*- coding: utf-8 -*-

# ------------- Comparaciones -------------

print (7 < 5)  # Falso
print (7 > 5)  # Verdadero
print ((11 * 3) + 2 == 36 - 1)  # Verdadero
print ((11 * 3) + 2 >= 36)      # Falso
print ("curso" != "CuRsO")    # Verdadero
print (5 and 4) #Operacion en binario 
print (5 or 4)
print (not(4 > 3))
print (True)
print (False)
