# -*- coding: utf-8 -*-

# ------------- Cantidad de segundos que has vivido -------------

# Definición de variables
anios = 30
dias_por_anio = 365
horas_por_dia = 24
segundos_por_hora = 60

# Operación
print (anios * dias_por_anio * horas_por_dia * segundos_por_hora)
