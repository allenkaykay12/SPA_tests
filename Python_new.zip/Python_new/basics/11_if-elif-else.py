# -*- coding: utf-8 -*-
# ------------- Estructura de selección if-else -------------

# if-elif-else
def numeros(entNum):
    if entNum == 1:
        print ("el número es 1")
    elif entNum == 2:
        print ("el número es 2")
    elif entNum == 3:
        print ("el número es 3")
    elif entNum == 4:
        print ("el número es 4")
    else:
        print ("Opción inválida")


numeros(1)
numeros(5)
