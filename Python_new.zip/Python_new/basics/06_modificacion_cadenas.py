# -*- coding: utf-8 -*-

#Cadena para buscar
cadena = "Amor y deseo son dos cosas diferentes, "
cadena = cadena + "que no todo lo que se ama se desea, "
cadena = cadena + "ni todo lo que se desea se ama. (Don Quijote)"

#Cambia todos los caracteres de la cadena a mayúsculas
cadena = cadena.upper()
print (cadena)

#Cambia todos los caracteres de la cadena a minúsculas
print (cadena.lower())

#Descomponiendo la cadena
print (cadena.split('TODO'))

#Reemplaza cadenas
print (cadena.replace("AMA", "COME"))