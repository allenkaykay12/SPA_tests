# -*- coding: utf-8 -*-

# Área de un círculo
pi = 3.14159
radio = 8
area_circulo = pi*(radio**2)

print("El área del círculo es ", area_circulo)
