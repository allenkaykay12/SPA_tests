# -*- coding: utf-8 -*-

# Área de un círculo
def area_circulo(entRadio):
    pi = 3.14159
    return pi*(radio**2)


radio = 8
area_circulo = area_circulo(radio)
print("El área del círculo es ", area_circulo)
