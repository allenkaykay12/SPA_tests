# Buggy Python

## Description
This repository contains several buggy python scripts. The purpose of the introduction of bugs is to test your attention to detail and problem solving skills.

## Requirements
The requirements for this project are simple and are as follows:
- Python3

## Instructions
Do not modify the existing logic, just find the bug in the code snippets and correct it.
The expected output when running the script is displayed in `main.py`
Do not modify the `main.py` file.
