from math_ops import divide


def main():
    for range in range(3):
        print("Hello")

    result = divide(10)
    print("Result:", result)

    print(undeclared_var)


main()
