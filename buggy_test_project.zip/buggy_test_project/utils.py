def greet_user(name):
    return "Hello " + names
